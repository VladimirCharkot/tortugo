# Tortugo

Latam translation of the python turtle module

Traducción a español latinoamericano del paquete `turtle`

Nombres en `src/tortugo/__init__py`
